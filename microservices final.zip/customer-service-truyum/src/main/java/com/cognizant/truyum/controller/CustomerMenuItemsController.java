package com.cognizant.truyum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.exception.MenuItemException;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/customer-menu-items")
public class CustomerMenuItemsController {
	
	@Autowired
	MenuItemService menuItemService;
	//http://localhost:8083/customer-truyum-service/customer-menu-items/menu-items
	@GetMapping("/menu-items")
	public List<MenuItem> getAllMenuItemscust() {
		log.info("Start");
		//log.debug("Menu Items : {}" + service.getAllMenuItemsAd);
		return menuItemService.getAllMenuItemsAd();
	}
	// http://localhost:8083/customer-truyum-service/customer-menu-items/1
	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable int id) throws MenuItemException {
		log.info("Start");
		log.debug("Menu Item : {}" + menuItemService.getMenuItemById(id));
		return menuItemService.getMenuItemById(id);
	}
}
