package com.cognizant.exception;

public class FavoritesEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public FavoritesEmptyException(String msg) {
		super(msg);
	}

}
