package com.cognizant.truyum.exception;

public class MenuItemException extends Exception {

	/**
	 * 
	 */
	public MenuItemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public MenuItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
