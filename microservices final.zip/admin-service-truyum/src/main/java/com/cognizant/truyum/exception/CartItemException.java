package com.cognizant.truyum.exception;

public class CartItemException extends Exception {

	/**
	 * 
	 */
	public CartItemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public CartItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
