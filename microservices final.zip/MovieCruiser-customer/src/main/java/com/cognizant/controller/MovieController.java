package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Movie;
import com.cognizant.service.MovieService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Ramesh
 *
 */
@RestController
@RequestMapping("/customer-movies")
@Slf4j
public class MovieController {

	@Autowired
	MovieService movieService;

	// http://localhost:8083/customer-movie-service/customer-movies/movie
	@GetMapping("/movie")
	public List<Movie> getMovieListCustomer() {
		log.info("start customer movie list");
		List<Movie> l = movieService.getMovieListCustomer();
		log.debug("Movies {}", l);
		log.info("Ended");
		
		return l;
	}

	/**
	 * 
	 * @param movieId
	 * @return the movie with the given Id
	 */
	// http://localhost:8083/customer-movie-service/customer-movies/1
	@GetMapping("/{movieId}")
	public Movie getMovie(@PathVariable int movieId) {
		log.info("start get movie by id customer");
		Movie movie = movieService.getMovie(movieId);
		log.debug("Movie {}", movie);
		log.info("Ended");
		return movie;
	}

	
	
}